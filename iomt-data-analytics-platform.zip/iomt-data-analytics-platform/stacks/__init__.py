"""IoMT Data Analytics Platform CDK Stacks"""
from .iomt_platform_stack import IoMTPlatformStack

__all__ = ["IoMTPlatformStack"]
